#include <stdio.h> 
#include <string.h> 
void main() 
{ 
	int dl,divl,i,j; 
	char div[50],data[50],data1[50]; 
	printf("\nEnter the codeword:"); 
	scanf("%s",data); 
	dl=strlen(data); 
	printf("\nEnter coefficients of generator polynomial:"); 
	scanf("%s",div); 
	divl=strlen(div); 
	strcpy(data1,data); 
	for(i=0;i<dl-(divl-1);i++) 
	{ 
		if(data[i]=='1') 
		{ 
			for(j=0;j<divl;j++) 
			{ 
				if(data[i+j]==div[j]) 
					data[i+j]='0'; 
				else 
					data[i+j]='1'; 
			} 
		} 
	} 
	j=0; 
	for(i=dl-(divl-1);i<dl;i++) 
		j=j+data[i]-48; 
	if(j==0) 
	{ 
		printf("Original data received\n"); 
		printf("Actual data : "); 
		for(i=0;i<dl-(divl-1);i++) 
			printf("%c ",data1[i]); 
	} 
	else 
		printf("Data received wrong \n"); 
}

